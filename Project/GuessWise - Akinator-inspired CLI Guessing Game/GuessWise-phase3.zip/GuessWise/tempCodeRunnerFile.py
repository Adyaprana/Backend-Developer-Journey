
                self.character_mode()