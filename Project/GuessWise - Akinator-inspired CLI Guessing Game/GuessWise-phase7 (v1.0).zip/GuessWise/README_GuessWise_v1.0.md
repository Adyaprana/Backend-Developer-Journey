# 🎯 GuessWise

> **A professional Akinator-inspired CLI game built from scratch to
> learn Backend Development, Software Architecture, Object-Oriented
> Programming, PostgreSQL, SQLAlchemy, and Clean Code.**

![Python](https://img.shields.io/badge/Python-3.12-blue)
![PostgreSQL](https://img.shields.io/badge/PostgreSQL-16-blue)
![SQLAlchemy](https://img.shields.io/badge/SQLAlchemy-2.0-red)
![Status](https://img.shields.io/badge/Status-v1.0-success)

## 📖 About

GuessWise is a command-line guessing game inspired by Akinator.

The project evolved from a simple JSON-based game into a layered backend
application using: - Repository Pattern - SQLAlchemy ORM - PostgreSQL -
Character Engine - Question Engine - Knowledge Manager

Its goal is to learn professional backend engineering by building a real
project step by step.

## ✨ Features

-   Interactive CLI
-   Character / Animal / Object categories
-   Dynamic question selection
-   Smart filtering
-   PostgreSQL database
-   SQLAlchemy ORM
-   Repository Pattern
-   Clean Architecture

## 🏗 Architecture

``` text
                 User
                   │
                   ▼
                 Game
                   │
                   ▼
          Knowledge Manager
          ├───────────────┐
          ▼               ▼
 Character Engine   Question Engine
          │               │
          └───────┬───────┘
                  ▼
        PostgreSQL Repository
                  │
                  ▼
             PostgreSQL
```

## 📂 Folder Structure

``` text
GuessWise/
├── database/
├── data/
├── engines/
├── models/
├── repository/
├── game.py
├── main.py
└── README.md
```

## 🚀 Development Journey

### Day 35--39

-   Designed the CLI game
-   JSON storage
-   Basic filtering
-   OOP foundation

### Day 40

-   Character Engine
-   Question Engine
-   Better separation of responsibilities

### Day 41

-   PostgreSQL migration
-   SQLAlchemy ORM
-   Repository abstraction
-   Database seeding

### Day 42

-   Knowledge Manager
-   Dynamic question selection
-   Final architecture cleanup
-   GuessWise CLI v1.0

## 📚 Concepts Learned

-   Object-Oriented Programming
-   SOLID
-   Repository Pattern
-   Dependency Injection
-   SQLAlchemy
-   PostgreSQL
-   Layered Architecture
-   Database Normalization
-   Clean Code
-   Refactoring

## 🔮 Future Roadmap

-   FastAPI
-   React / Next.js
-   Authentication
-   Admin Panel
-   AI-powered decision engine
-   Entropy / Information Gain

## 👨‍💻 Developer

**Adyaprana Pradhan**

Built as part of my Backend Developer Journey.

## 📄 License

MIT License
