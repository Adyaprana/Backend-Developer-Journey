# 🎯 GuessWise --- Intelligent Guessing Engine

> **A production-style backend project documenting my journey from a
> simple JSON CLI application to a modular, database-driven decision
> engine inspired by Akinator.**

> **Backend Developer Journey • Days 35--42**

------------------------------------------------------------------------

# 📑 Table of Contents

-   Vision
-   Features
-   Demo
-   Screenshots
-   Architecture
-   Database Design
-   Development Journey
-   Design Decisions
-   Algorithms
-   Folder Structure
-   Installation
-   Testing
-   Performance
-   Interview Questions
-   Lessons Learned
-   Roadmap
-   Developer

------------------------------------------------------------------------

# 🎨 Hero Banner (SVG)

Create a file named `assets/banner.svg` and place it at the top of this
README.

Suggested title:

**GuessWise** *An Intelligent Akinator-Inspired Guessing Engine*

------------------------------------------------------------------------

# 📸 CLI Demo

Replace these placeholders with your own screenshots.

``` text
assets/
 ├── home.png
 ├── gameplay.png
 ├── guessed.png
 └── database.png
```

``` md
![Home](assets/home.png)

![Gameplay](assets/gameplay.png)

![Guess](assets/guessed.png)
```

------------------------------------------------------------------------

# 🎬 Terminal Demo GIF

Add:

``` md
![Demo](assets/demo.gif)
```

A 20--30 second terminal recording using asciinema or ScreenToGif works
well.

------------------------------------------------------------------------

# 🌟 Vision

GuessWise was built to learn backend engineering the way production
software evolves.

Instead of building a single script, the project was continuously
refactored to improve architecture, maintainability and scalability.

Goals:

-   Practice OOP
-   Learn SOLID
-   Apply Repository Pattern
-   Learn SQLAlchemy
-   Learn PostgreSQL
-   Build clean architecture
-   Create a decision engine

------------------------------------------------------------------------

# ✨ Features

-   Character guessing
-   Animal guessing
-   Object guessing
-   Dynamic question selection
-   Smart candidate filtering
-   PostgreSQL backend
-   SQLAlchemy ORM
-   Repository abstraction
-   Engine-based architecture

------------------------------------------------------------------------

# 🏗 Final Architecture

``` text
                 User
                   │
                   ▼
                 Game
                   │
                   ▼
          Knowledge Manager
          ├───────────────┐
          ▼               ▼
 Character Engine   Question Engine
          │               │
          └───────┬───────┘
                  ▼
        PostgreSQL Repository
                  │
                  ▼
             PostgreSQL
```

------------------------------------------------------------------------

# 📊 Before vs After

## Version 0

``` text
Game
 ├── Questions
 ├── Filtering
 ├── JSON
 └── Everything
```

## Version 1

``` text
Game
│
├── KnowledgeManager
├── CharacterEngine
├── QuestionEngine
└── Repository
```

Responsibilities are isolated and every class has one job.

------------------------------------------------------------------------

# 🧠 Decision Engine

Flow:

``` text
Remaining Characters
        │
        ▼
Remaining Questions
        │
        ▼
Knowledge Manager
        │
        ▼
Choose Best Split
        │
        ▼
Ask Question
        │
        ▼
Filter Candidates
        │
        ▼
Repeat
```

Current heuristic:

    score = abs(true_count - false_count)

Future versions will replace this with Information Gain / Entropy.

------------------------------------------------------------------------

# 🗄 PostgreSQL ER Diagram

``` text
Characters
    │
    ├────────────┐
    ▼            ▼
CharacterAttributes
    ▲            │
    │            ▼
 Attributes <── Questions
```

Normalization avoids duplicate attribute names and allows many questions
to reference one attribute.

------------------------------------------------------------------------

# 📅 Development Diary

## Day 35

Project planning.

## Day 36

Initial CLI.

## Day 37

Character filtering.

## Day 38

Question handling.

## Day 39

Repository preparation.

## Day 40

CharacterEngine + QuestionEngine.

## Day 41

Migrated to PostgreSQL and SQLAlchemy.

## Day 42

Knowledge Manager, architecture cleanup and CLI v1.0.

------------------------------------------------------------------------

# 📖 Major Design Decisions

### Why Repository Pattern?

To replace JSON with PostgreSQL without changing game logic.

### Why CharacterEngine?

Filtering belongs to characters, not Game.

### Why QuestionEngine?

Question storage belongs in one place.

### Why KnowledgeManager?

The Game should never decide which question to ask.

### Why PostgreSQL?

Real applications require persistent, relational storage.

------------------------------------------------------------------------

# 📂 Folder Structure

``` text
GuessWise/
├── database/
├── repository/
├── engines/
├── models/
├── data/
├── game.py
├── main.py
└── README.md
```

------------------------------------------------------------------------

# 🧪 Testing

Manual test checklist:

-   Load all categories
-   Dynamic question selection
-   Candidate filtering
-   Final guess
-   No candidate case
-   Play again flow
-   PostgreSQL loading

------------------------------------------------------------------------

# 📈 Performance

Current complexity:

-   Best question: O(Q × C)
-   Character filtering: O(C)

Current dataset (\~150 entities) performs instantly.

Future optimizations:

-   Indexing
-   Cached scores
-   Entropy pruning

------------------------------------------------------------------------

# 💼 Interview Questions

-   Why did you use the Repository Pattern?
-   Why normalize the database?
-   Why introduce CharacterEngine?
-   Why separate KnowledgeManager?
-   How would you improve the decision algorithm?
-   Why SQLAlchemy instead of raw SQL?
-   How would you convert this into a web application?

------------------------------------------------------------------------

# 🧭 Lessons Learned

-   Refactoring is part of development.
-   Architecture matters more as projects grow.
-   Separation of concerns makes features easier to add.
-   Databases replace flat files cleanly when abstraction exists.
-   Good documentation improves maintainability.

------------------------------------------------------------------------

# 🚀 Roadmap

## v2

-   FastAPI
-   REST API
-   React / Next.js
-   JWT Authentication
-   Docker
-   Admin Dashboard

## v3

-   Information Gain
-   Entropy
-   Machine Learning
-   Self-learning knowledge base
-   User accounts
-   Analytics

------------------------------------------------------------------------

# 👨‍💻 Developer

**Adyaprana Pradhan**

Built as part of my Backend Developer Journey.

Portfolio, GitHub and LinkedIn can be added here.

------------------------------------------------------------------------

# ⭐ Support

If you found this project useful, consider giving it a ⭐ on GitHub.
